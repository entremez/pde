
<div class="col-md-10 offset-md-1 my-5 text-center" >

		<div class="col-md-6 offset-md-3">
			<img src="{{ asset('images/logo-bp-0051.png') }}" alt="logo puente diseño empresa" class="img-soon">

			<p class="mt-4 ls">El diseño mejora tu negocio. Pronto podrás saber como.</p>
		</div>
	<div class="row mt-5">
		<div class="col-md-6 offset-md-3">
			<div class="row footer-logos">   
			    <div class="logos">
			        <img src="{{ asset('images/footer/uc.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/disenouc.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/mada.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/corfo.png') }}">
			    </div>  
			    <div class="logos">
			        <img src="{{ asset('images/footer/gobchile.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/chilecreativo.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/chilediseno.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/sofofa.png') }}">
			    </div>  
			    <div class="logos">
			        <img src="{{ asset('images/footer/colegiodiseno.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/minculturas.png') }}">
			    </div>
			    <div class="logos">
			        <img src="{{ asset('images/footer/minturismo.png') }}">
			    </div>
			    <div class="logos">
			        
			    </div>
			</div>
		</div>
	</div>
</div>

