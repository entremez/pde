@extends('layouts.puente')
@section('title', 'PDE | Verifica tu correo')

@section('content')

@include('partials/menu')
<div class="after-menu"></div>

<div class="col-md-10 offset-md-1">

	<h3 class="mt-5 text-center">Te enviamos un link para verificar tu correo...</h3>
</div>



@include('partials/footer')

@endsection
