<div class="row">
	<a class="link-default"  style="border-bottom: 1px solid #333" href="{{ route('home') }}">Inicio</a>
	<hr>	
</div>
<br>

<div class="row">
	<a class="link-default" style="border-bottom: 1px solid #333" href="{{ route('timeline')}}">Mis viajes</a>
	<hr>	
</div>