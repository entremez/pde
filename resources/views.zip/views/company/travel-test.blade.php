@extends('layouts.puente')
@section('title', 'PDE | Viaje')

@section('content')

@include('company.travel')

@endsection
