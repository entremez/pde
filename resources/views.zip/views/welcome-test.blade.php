@extends('layouts.puente')
@section('title', 'Puente DE')

@section('content')








@include('partials/footer')


@endsection