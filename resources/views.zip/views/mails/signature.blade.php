<br>
<table style="margin-top:20px; font-family: Arial, Helvetica, sans-serif; height:90px; border-collapse: collapse; border: ">
  <tr>
    <td style="padding:7px 7px 7px 11px">
      <img src="http://www.puentedisenoempresa.cl/images/logo-bp-0051.png" 
         alt="Metalúrgica Industrial Tobalaba" 
         width="140" 
         height="80" 
         style="display:block; float: left;"
       >
    </td>
    
    <td style="height:100px; background:#ccc; float: right"><br></td>
    
    
    <td style="vertical-align:middle; padding:7px 14px 7px 11px">
      
      <strong style="margin: 0; font-size:13px; color: rgba(40, 45, 49,.9); line-height: 24px; height: 24px; display:block">Equipo Puente Diseño Empresa</strong>
      
      <p style='font-size:12px; margin: 0px 0 6px; height: 40px'>
        <a href="mailto:equipo@puentedisenoempresa.cl" style="color: #666;text-decoration: none" ><i>equipo@puentedisenoemepresa.cl</i></a>
        
        <br>
        <br>
        <a href='https://www.puentedisenoempresa.cl' style="color:#666; text-decoration: none">www.puentedisenoempresa.cl</a>
        
      </p>
    </td>
  </tr>
</table>