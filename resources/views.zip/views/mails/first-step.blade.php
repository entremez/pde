<body>
<div class="container">
	<div class="row ">
		<img src="http://box5677.temp.domains/~yebizbmy/images/logo.png">
	</div>
	<div class="row">
		<div class="col">
			<p>Bienvenido</p>
		</div>
	</div>
</div>
</body>