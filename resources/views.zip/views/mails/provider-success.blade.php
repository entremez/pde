<body>
	<div class="row">
		{!! $body !!}
	<br>
		@include('mails/signature')
	</div>
</body>