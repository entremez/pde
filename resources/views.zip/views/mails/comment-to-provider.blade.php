
<body>
	<div style="margin: 0 auto">
		<img src="http://box5677.temp.domains/~yebizbmy/images/logo.png" class="mx-auto d-block" alt="Puente Diseño Empresa Logo">
	</div>
	<div class="row">
		<p>{!! $comment !!}</p>

		@include('mails/signature')
	</div>
</body>