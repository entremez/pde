<h2>Hola!</h2>
<p>Tu contraseña ha sido modificada exitosamente.</p>


@include('mails/signature')
