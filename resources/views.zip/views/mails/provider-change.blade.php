
<body>
	<div class="row">
		<p>{{ $email }}</p>
	</div>
</body>