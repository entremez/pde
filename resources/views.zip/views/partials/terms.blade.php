<div class="row">
    <div class="col mb-4">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="terms" name="terms" required style="    margin-top: 7px;">
          <label class="form-check-label" for="terms">
            Acepto los <a href="{{ asset('documents/Términos y Condiciones - Puente Diseño Empresa v2.pdf') }}" target="_blank">términos y condiciones</a>
          </label>
        </div>
        <div class="errorTerms"></div>
    </div>
</div>