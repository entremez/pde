					<table width="100%" style="margin-top: 15px">
						<tr>
							<td width="50%" height="50px">
								<div class="providers-image">
								<img  height="50px" src="{{ $providers[0]->imagen_logo }}">
								</div>
							</td>
							<td width="50%" height="50px">

							</td>
						</tr>
						<tr>
							<td width="50%" height="50px">
								<div class="text-center">
									<div class="font-bold">{{ $providers[0]->name }}</div>
									<div class="web font-regular">{{ $providers[0]->web }}</div>
								</div>
							</td>
							<td width="50%" height="50px">

							</td>
						</tr>
						<tr>
							<td width="50%" height="50px">

							</td>
							<td width="50%" height="50px">

							</td>
						</tr>
						<tr>
							<td width="50%" height="50px">

							</td>
							<td width="50%" height="50px">

							</td>
						</tr>
						<tr>
							<td width="50%" height="50px">

							</td>
							<td width="50%" height="50px">

							</td>
						</tr>
						<tr>
							<td width="50%" height="50px">

							</td>
							<td width="50%" height="50px">

							</td>
						</tr>
					</table>