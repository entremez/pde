<footer class="footer section">  
    <div class="section">
        <div class="menu-container footer-container">
            <div>
                <p>El proyecto Bien Público</p>
                <ul>
                    <li>Ecosistema del proyecto</li>
                    <li>El equipo</li>
                    <li>Formulación</li>
                </ul>
            </div>
            <div>
                <p>Reportes</p>
            </div>
            <div>
                <p>Links de interés</p>
            </div>
            <div>
                <p>Contáctanos</p>
            </div>
        </div>
    </div>
</footer>