<footer class="footer section">  
    <div class="section">
        <div class="menu-container footer-container">
            <div class="col-md-3">
                <p>El proyecto Bien Público</p>
                <ul class="dashed">
                    <li>Ecosistema del proyecto</li>
                    <li>El equipo</li>
                    <li>Formulación</li>
                </ul>
            </div>
            <div class="col-md-2">

                    <p>Reportes</p>
                    <p>Links de interés</p>
                    <p>Contáctanos</p>

            </div>
            <div class="col-md-7 col-sm-12">
                <div class="row footer-logos">   
                    <div class="logof">
                        <img src="{{ asset('images/footer/uc.png') }}">
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/disenouc.png') }}">
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/mada.png') }}">
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/corfo.png') }}">
                    </div>  
                    <div class="logof">
                        <img src="{{ asset('images/footer/gobchile.png') }}">
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/chilecreativo.png') }}">
                    </div>
                    <div class="logof">
                        <div class="mma">
                        <img src="{{ asset('images/footer/chilediseno.png') }}">
                        </div>
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/sofofa.png') }}">
                    </div>  
                    <div class="logof">
                        <img src="{{ asset('images/footer/colegiodiseno.png') }}">
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/minculturas.png') }}">
                    </div>
                    <div class="logof">
                        <img src="{{ asset('images/footer/minturismo.png') }}">
                    </div>
                    <div class="logof" style="width: 150px">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>