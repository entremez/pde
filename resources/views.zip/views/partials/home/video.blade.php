
<div class="video-container">
	<div class="section-title video-title">
		<p class="mt-0"><span class="first-color">EL DISEÑO </span> <span class="secondary-color">MEJORA TU NEGOCIO</span></p>
	</div>

	<video poster="{{ url('images/poster.png') }}" playsinline autoplay muted loop preload width="100%" height="600">

		<source src="{{ url('images/test.mp4') }}" type="video/mp4">
	</video>
</div>
