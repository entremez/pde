<div class="col-md-12  section">
    <hr class="divider">
    <div class="row w-100">
        <div class="col-md-6 banner-left">
            <div class="section-title"><pre class="averigua" >Averigua cuanto aporta
el diseño en tu empresa hoy</pre></div>
            <button class="btn btn-danger btn-averigua">Evalúa tu empresa hoy</button>
        </div>
        <div class="col-md-6 rentabilidad">
            <div class="txt-center">
            <p class="h5">El diseño mejora significativamente la rentabilidad de los negocios. </p>
            <p class="text-justify">El viaje Puente Diseño Empresa es una herramienta que te ayudará a descubrir qué nivel de diseño tiene tu empresa, te guiará en cómo puedes integrar diseño y qué tipo de diseño es el indicado para tus desafíos.</p>
            </div>
        </div>
    </div>
    <hr class="divider">
</div>
