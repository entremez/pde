
<div class="col-md-10 offset-md-1">
    <div class="row">
        <div class="col-md-6 wow fadeInUp">
            <h4 class="py-4"><span class="first-color">Proveedores</span> <span class="secondary-color">de servicios de Diseño</span></h4>
            <div class="row">
            @foreach($providers as $provider)
                <div class="col-md-6 ">
                    <div class="image-container" style="background-image: url({{ $provider->logo }});"></div>
                </div>
                <div class="col-md-6 vertical-line mb-3">
                    <h6 class="provider-title">{{ $provider->name }}</h6>
                    <h6 class="provider-services">Servicios: {{ $provider->all_services }}</h6>
                </div>
            @endforeach
            </div>
            <a class="btn btn-danger btn-block mt-3" href="{{ route('providers-list')}}">MÁS PROVEEDORES DE DISEÑO</a>
        </div>
        <div class="col-md-6 wow fadeInUp">
            <h4 class="py-4"><span class="first-color">Documentos</span> <span class="secondary-color">de interes</span></h4>
            <div class="row">
            @foreach($providers as $provider)
                <div class="col-md-6 ">
                    <div class="image-container" style="background-image: url(https://picsum.photos/1000/400?image={{ rand(1,500)}});"></div>
                </div>
                <div class="col-md-6 mb-3">
                    <h6>Autor y año de edición</h6>
                    <h6>Ciudad</h6>
                </div>
            @endforeach
            </div>
            <button class="btn btn-danger btn-block mt-3">DOCUMENTOS</button>
        </div>
    </div>
</div>
