<div class="video-container" id="video">
  <video poster="{{ url('images/poster.png') }}" id="bgvid" playsinline autoplay muted loop preload>

  <source src="{{ url('images/test.mp4') }}" type="video/mp4">
  </video>
</div>