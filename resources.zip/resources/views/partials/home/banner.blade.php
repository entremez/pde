
<div class="col-md-12 py-5 px-0">
    <hr class="divider">
    <div class="row w-100">
        <div class="col-md-6 banner-left wow fadeInLeft" style="background-image: url(https://picsum.photos/800/600?image=120);">
            <h4><pre class="averigua" >Averigua cuanto aporta
el diseño en tu empresa hoy</pre></h4>
            <button class="btn btn-danger btn-averigua">Evalúa tu empresa hoy</button>
        </div>
        <div class="col-md-6 rentabilidad  wow fadeInRight">
            <p class="text-left h5">El diseño mejora significativamente la rentabilidad de los negocios. </p>
            <p>El viaje Puente Diseño Empresa es una herramienta que te ayudará a descubrir qué nivel de diseño tiene tu empresa, te guiará en cómo puedes integrar diseño y qué tipo de diseño es el indicado para tus desafíos.</p>
        </div>
    </div>
    <hr class="divider">
</div>
