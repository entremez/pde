<footer class="footer">
    <div class="container container-footer">
        <div class="row">
            <div class="col-md-3">
                <p>El proyecto Bién Público</p>
                <ul>
                    <li>Ecosistema del proyecto</li>
                    <li>El equipo</li>
                    <li>Formulación</li>
                </ul>
            </div>
            <div class="col footer-item">
                <p>Reportes</p>
                <p>aLinks de interés</p>
                <p><a class="link" href="{{ route('provider-register') }}">Registrate como proveedor de diseño</a></p>
                <p>Contáctanos</p>
            </div>
        </div>
    </div>
</footer>